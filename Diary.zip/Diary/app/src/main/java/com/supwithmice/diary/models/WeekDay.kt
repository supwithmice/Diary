package com.supwithmice.diary.models

data class WeekDay(
    val date: String,
    val lessons: List<Lesson>
)