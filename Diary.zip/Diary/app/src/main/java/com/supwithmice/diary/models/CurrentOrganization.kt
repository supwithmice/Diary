package com.supwithmice.diary.models

data class CurrentOrganization(
    val id: Int,
    val name: String
)