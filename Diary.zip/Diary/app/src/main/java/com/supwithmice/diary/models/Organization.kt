package com.supwithmice.diary.models

data class Organization(
    val id: Int,
    val name: String
)