package com.supwithmice.diary.models

data class ArchiveStatus(
    val date: Any,
    val status: Int
)