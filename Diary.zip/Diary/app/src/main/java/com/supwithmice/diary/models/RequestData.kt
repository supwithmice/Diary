package com.supwithmice.diary.models

data class RequestData(
    val warnType: String
)