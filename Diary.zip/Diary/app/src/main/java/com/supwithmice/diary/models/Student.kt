package com.supwithmice.diary.models

data class Student(
    val classId: Int,
    val className: Any,
    val iupGrade: Int,
    val nickName: String,
    val studentId: Int
)