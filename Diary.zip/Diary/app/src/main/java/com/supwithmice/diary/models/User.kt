package com.supwithmice.diary.models

data class User(
    val id: Int,
    val name: String
)