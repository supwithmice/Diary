package com.supwithmice.diary.models

data class GetDataModel(
    val lt: String,
    val salt: String,
    val ver: String
)